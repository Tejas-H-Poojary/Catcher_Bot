#!/usr/bin/env python3
"""
simulate.py
------------
Standalone 2D pursuit-evasion match simulator. Runs the EXACT same
CatcherBrain / RunnerBrain classes used by the ROS2 nodes, against a
hand-rolled arena + LIDAR ray-caster, so you can test and tune the
algorithms with nothing but `python3` -- no ROS2, no Gazebo required.

Usage:
    python3 simulate.py                       # one match, prints result
    python3 simulate.py --plot out.png        # also saves a trajectory plot
    python3 simulate.py --matches 20          # batch-run and report win rate
    python3 simulate.py --seed 7 --plot m.png

Match rules mirror the rulebook: 10x10m arena, 4-6 static obstacles,
3.0m initial separation, 3-minute (180s) inning, capture = within 0.5m
sustained for 1.0s continuously.
"""
import argparse
import math
import sys

from turtlebot_pursuit_evasion.core.arena import Arena
from turtlebot_pursuit_evasion.core.catcher_brain import CatcherBrain
from turtlebot_pursuit_evasion.core.runner_brain import RunnerBrain
from turtlebot_pursuit_evasion.core.geometry import world_to_robot_frame

CAPTURE_RADIUS = 0.5
CAPTURE_HOLD_TIME = 1.0
INNING_DURATION = 180.0
INITIAL_DISTANCE = 3.0
DT = 0.1


def make_start_poses(arena: Arena, seed: int):
    """Place both robots INITIAL_DISTANCE apart, clear of obstacles,
    roughly centred in the arena (rulebook: 'Start: Both robots
    simultaneously', 'Head start: None')."""
    import random
    rng = random.Random(seed + 1000)
    cx, cy = arena.width / 2, arena.height / 2
    for _ in range(200):
        heading = rng.uniform(0, 2 * math.pi)
        cx_try = cx + rng.uniform(-1.0, 1.0)
        cy_try = cy + rng.uniform(-1.0, 1.0)
        cx1 = cx_try - (INITIAL_DISTANCE / 2) * math.cos(heading)
        cy1 = cy_try - (INITIAL_DISTANCE / 2) * math.sin(heading)
        cx2 = cx_try + (INITIAL_DISTANCE / 2) * math.cos(heading)
        cy2 = cy_try + (INITIAL_DISTANCE / 2) * math.sin(heading)
        if arena.in_collision(cx1, cy1) or arena.in_collision(cx2, cy2):
            continue
        catcher_pose = [cx1, cy1, heading]
        runner_pose = [cx2, cy2, math.pi + heading]
        return catcher_pose, runner_pose
    # Fallback (shouldn't happen with default obstacle counts)
    return [cx - 1.5, cy, 0.0], [cx + 1.5, cy, math.pi]


def run_match(seed: int = 0, n_obstacles: int = 5, verbose: bool = True):
    arena = Arena(n_obstacles=n_obstacles, seed=seed)
    catcher_pose, runner_pose = make_start_poses(arena, seed)

    catcher_brain = CatcherBrain()
    runner_brain = RunnerBrain(seed=seed + 1)

    catcher_traj = [tuple(catcher_pose[:2])]
    runner_traj = [tuple(runner_pose[:2])]

    capture_timer = 0.0
    t = 0.0
    dist = math.hypot(catcher_pose[0] - runner_pose[0], catcher_pose[1] - runner_pose[1])
    captured = False

    while t < INNING_DURATION:
        c_scan, c_amin, c_ainc = arena.cast_lidar(catcher_pose)
        r_scan, r_amin, r_ainc = arena.cast_lidar(runner_pose)

        # Ground-truth relative opponent position (the standalone sim
        # stands in for whatever perception source is configured in
        # perception.py -- see README "Perception assumptions").
        dxc = runner_pose[0] - catcher_pose[0]
        dyc = runner_pose[1] - catcher_pose[1]
        opp_rel_for_catcher = world_to_robot_frame(dxc, dyc, catcher_pose[2])

        dxr = catcher_pose[0] - runner_pose[0]
        dyr = catcher_pose[1] - runner_pose[1]
        opp_rel_for_runner = world_to_robot_frame(dxr, dyr, runner_pose[2])

        c_lin, c_ang = catcher_brain.compute_cmd(catcher_pose, opp_rel_for_catcher, c_scan, c_amin, c_ainc, DT)
        r_lin, r_ang = runner_brain.compute_cmd(runner_pose, opp_rel_for_runner, r_scan, r_amin, r_ainc, DT)

        catcher_pose = arena.step(catcher_pose, c_lin, c_ang, DT)
        runner_pose = arena.step(runner_pose, r_lin, r_ang, DT)

        catcher_traj.append(tuple(catcher_pose[:2]))
        runner_traj.append(tuple(runner_pose[:2]))

        dist = math.hypot(catcher_pose[0] - runner_pose[0], catcher_pose[1] - runner_pose[1])
        if dist < CAPTURE_RADIUS:
            capture_timer += DT
            if capture_timer >= CAPTURE_HOLD_TIME:
                captured = True
                break
        else:
            capture_timer = 0.0

        t += DT

    winner = "CATCHER" if captured else "RUNNER"
    if verbose:
        print(f"seed={seed:<4} winner={winner:<8} t={t:6.1f}s  final_dist={dist:5.2f}m  obstacles={len(arena.obstacles)}")
    return {
        "winner": winner,
        "time": t,
        "final_distance": dist,
        "catcher_traj": catcher_traj,
        "runner_traj": runner_traj,
        "arena": arena,
    }


def plot_match(result, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle, Rectangle

    arena = result["arena"]
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.add_patch(Rectangle((0, 0), arena.width, arena.height, fill=False, linewidth=2, edgecolor="black"))
    for o in arena.obstacles:
        ax.add_patch(Circle((o.x, o.y), o.radius, color="dimgray"))

    ct = result["catcher_traj"]
    rt = result["runner_traj"]
    ax.plot([p[0] for p in ct], [p[1] for p in ct], color="crimson", linewidth=1.5, label="Catcher path")
    ax.plot([p[0] for p in rt], [p[1] for p in rt], color="royalblue", linewidth=1.5, label="Runner path")
    ax.scatter(*ct[0], color="crimson", marker="o", s=70, zorder=5, label="Catcher start")
    ax.scatter(*rt[0], color="royalblue", marker="o", s=70, zorder=5, label="Runner start")
    ax.scatter(*ct[-1], color="crimson", marker="X", s=120, zorder=6, label="Catcher end")
    ax.scatter(*rt[-1], color="royalblue", marker="X", s=120, zorder=6, label="Runner end")

    if result["winner"] == "CATCHER":
        ax.add_patch(Circle(ct[-1], CAPTURE_RADIUS, color="gold", alpha=0.4, label="Capture radius"))

    ax.set_xlim(-0.5, arena.width + 0.5)
    ax.set_ylim(-0.5, arena.height + 0.5)
    ax.set_aspect("equal")
    ax.set_title(f"Winner: {result['winner']}  (t={result['time']:.1f}s, "
                 f"final dist={result['final_distance']:.2f}m)")
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    print(f"Saved trajectory plot to {path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--obstacles", type=int, default=5)
    parser.add_argument("--plot", type=str, default=None, help="Path to save a trajectory PNG for a single match")
    parser.add_argument("--matches", type=int, default=1, help="Run N matches (different seeds) and report win rate")
    args = parser.parse_args()

    if args.matches > 1:
        wins = {"CATCHER": 0, "RUNNER": 0}
        for i in range(args.matches):
            result = run_match(seed=args.seed + i, n_obstacles=args.obstacles)
            wins[result["winner"]] += 1
        print(f"\n{args.matches} matches -> Catcher wins: {wins['CATCHER']}  "
              f"Runner wins: {wins['RUNNER']}  "
              f"(Catcher win rate: {wins['CATCHER'] / args.matches:.0%})")
    else:
        result = run_match(seed=args.seed, n_obstacles=args.obstacles)
        if args.plot:
            plot_match(result, args.plot)


if __name__ == "__main__":
    sys.exit(main())
