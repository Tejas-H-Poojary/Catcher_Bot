"""
perception.py
--------------
Provides the opponent's position relative to this robot. This is the one
piece of the system the published rulebook is genuinely silent on -- it
promises full sensor/topic details "through the official technical
rulebook" but that hasn't been released yet -- so this module makes the
assumption explicit and easy to swap out later (see README.md
"Assumptions we had to make").

Two modes, selected via the `perception_mode` ROS parameter:

  'ground_truth' (default): subscribes to Gazebo's ground-truth model
      pose topic and reads the opponent model's position directly. Lets
      you get everything else (pursuit, evasion, obstacle avoidance)
      running and testable immediately, and mirrors how a lot of
      educational pursuit-evasion competitions are actually judged (the
      organizers' harness gets ground truth even when the robots don't).
      CAVEAT: the exact topic/message type depends on which Gazebo <-> ROS2
      bridge the official simulation uses:
        - Gazebo Classic + gazebo_ros: gazebo_msgs/ModelStates on
          '/gazebo/model_states'  (what's wired up below)
        - Gazebo Fortress/Harmonic + ros_gz_bridge: typically per-entity
          pose topics or 'ros_gz_interfaces/msg/EntityStateArray' bridged
          individually -- swap out `_model_states_cb`/the subscription
          for whatever the rulebook specifies once it's released. The
          rest of the stack (brains, control loop) does not change.

  'lidar': a lightweight "map-differencing" opponent detector, for once
      ground truth is not available (e.g. the real qualification round,
      where the Catcher must find a target with no side-channel at all).
      It ray-casts the STATIC obstacle map (must be supplied via the
      `static_obstacles` parameter) to get the *expected* LIDAR return in
      the current pose, then looks for contiguous beams in the *actual*
      scan that are significantly closer than expected -- i.e. something
      is there that isn't on the static map. The centroid of the largest
      such cluster is reported as the opponent's position. This is
      noisier than ground truth and needs the static obstacle layout
      ahead of time, but does not depend on any simulator-only topic.
"""
import math

from .core.geometry import world_to_robot_frame

try:
    from gazebo_msgs.msg import ModelStates
except ImportError:  # pragma: no cover - only needed for 'ground_truth' mode
    ModelStates = None


class OpponentTracker:
    def __init__(self, node, opponent_model_name: str, mode: str = 'ground_truth',
                 static_obstacles=None, detection_max_age: float = 0.5):
        """
        node: the owning rclpy Node (used for subscriptions + clock)
        opponent_model_name: Gazebo model name of the opponent robot
            (only used in 'ground_truth' mode)
        mode: 'ground_truth' or 'lidar'
        static_obstacles: list of (x, y, radius) tuples describing the
            known static obstacle layout (only used in 'lidar' mode)
        detection_max_age: seconds after which a stale detection is
            treated as "opponent not currently visible" rather than
            trusted -- avoids driving towards a last-known position long
            after it has gone stale.
        """
        self._node = node
        self._opponent_model_name = opponent_model_name
        self._mode = mode
        self._static_obstacles = list(static_obstacles or [])
        self._detection_max_age = detection_max_age

        self._opponent_world_xy = None
        self._last_seen_time = None

        if mode == 'ground_truth':
            if ModelStates is None:
                raise RuntimeError(
                    "perception_mode='ground_truth' requires gazebo_msgs, which "
                    "isn't importable in this environment. Install it, or switch "
                    "to perception_mode='lidar'."
                )
            node.create_subscription(ModelStates, '/gazebo/model_states', self._model_states_cb, 10)
        elif mode != 'lidar':
            raise ValueError(f"Unknown perception_mode '{mode}' (expected 'ground_truth' or 'lidar')")

    # ------------------------------------------------------------------
    def _model_states_cb(self, msg):
        try:
            idx = msg.name.index(self._opponent_model_name)
        except ValueError:
            return  # opponent model not published under this name (yet?)
        pos = msg.pose[idx].position
        self._opponent_world_xy = (pos.x, pos.y)
        self._last_seen_time = self._node.get_clock().now()

    # ------------------------------------------------------------------
    def update_from_scan(self, own_pose, ranges, angle_min, angle_increment, max_range: float = 8.0):
        """Only meaningful in 'lidar' mode. Call this once per incoming
        LaserScan, before get_opponent_relative()."""
        if self._mode != 'lidar':
            return
        x, y, theta = own_pose
        ranges = list(ranges)
        n = len(ranges)
        if n == 0:
            return

        expected = [self._expected_range(x, y, theta + angle_min + i * angle_increment, max_range)
                    for i in range(n)]

        # Beams noticeably closer than the static map's expectation mean
        # something dynamic is there -- in this competition, the only
        # thing that can be is the opponent robot.
        diff_threshold = 0.25  # metres
        dynamic_idxs = [i for i in range(n)
                         if ranges[i] < expected[i] - diff_threshold and ranges[i] < max_range]
        if not dynamic_idxs:
            return

        clusters = self._cluster_indices(dynamic_idxs, n)
        best_cluster = max(clusters, key=len)
        if len(best_cluster) < 2:
            return  # a single noisy beam isn't a robot

        pts = []
        for i in best_cluster:
            ang = theta + angle_min + i * angle_increment
            r = ranges[i]
            pts.append((x + r * math.cos(ang), y + r * math.sin(ang)))
        self._opponent_world_xy = (sum(p[0] for p in pts) / len(pts),
                                    sum(p[1] for p in pts) / len(pts))
        self._last_seen_time = self._node.get_clock().now()

    def _expected_range(self, x, y, ang, max_range):
        dx, dy = math.cos(ang), math.sin(ang)
        best = max_range
        for (ox, oy, orad) in self._static_obstacles:
            lx, ly = ox - x, oy - y
            tca = lx * dx + ly * dy
            if tca < 0:
                continue
            d2 = lx * lx + ly * ly - tca * tca
            r2 = orad * orad
            if d2 > r2:
                continue
            thc = math.sqrt(max(r2 - d2, 0.0))
            t0 = tca - thc
            t = t0 if t0 >= 0 else tca + thc
            if 0 <= t < best:
                best = t
        return best

    @staticmethod
    def _cluster_indices(idxs, n):
        """Group nearby beam indices into contiguous clusters, merging
        across the 0/n-1 wraparound seam."""
        idxs = sorted(idxs)
        clusters = []
        current = [idxs[0]]
        for i in idxs[1:]:
            if i - current[-1] <= 2:
                current.append(i)
            else:
                clusters.append(current)
                current = [i]
        clusters.append(current)
        if len(clusters) > 1 and clusters[0][0] == 0 and clusters[-1][-1] >= n - 3:
            clusters[0] = clusters[-1] + clusters[0]
            clusters.pop()
        return clusters

    # ------------------------------------------------------------------
    def get_opponent_relative(self, own_pose):
        """Returns (dx, dy) in the robot's LOCAL frame, or None if the
        opponent has not been seen recently enough to trust."""
        if self._opponent_world_xy is None:
            return None
        if self._last_seen_time is not None:
            age = (self._node.get_clock().now() - self._last_seen_time).nanoseconds / 1e9
            if age > self._detection_max_age:
                return None
        x, y, theta = own_pose
        dx = self._opponent_world_xy[0] - x
        dy = self._opponent_world_xy[1] - y
        return world_to_robot_frame(dx, dy, theta)


def quaternion_to_yaw(q) -> float:
    """geometry_msgs/Quaternion -> yaw (radians). A tiny helper so nodes
    don't need a hard dependency on tf_transformations (not always
    installed) just to read odometry heading."""
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)
