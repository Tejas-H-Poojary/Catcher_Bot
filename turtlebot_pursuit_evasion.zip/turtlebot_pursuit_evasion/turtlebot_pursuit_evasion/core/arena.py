"""
arena.py
--------
A tiny, dependency-light (numpy only) 2D arena model used exclusively by
the standalone simulator (simulate.py). It is NOT used by the ROS2 nodes
in a real match -- there, the real Gazebo world and the real TurtleBot
LIDAR provide this information. This file exists so the exact same
CatcherBrain / RunnerBrain code can be exercised and tuned without ROS2
or Gazebo installed.

Arena matches the rulebook defaults:
    10m x 10m flat enclosed square, 4-6 static circular obstacles.
"""
import math
import random
from dataclasses import dataclass, field
from typing import List, Tuple

from .geometry import wrap_angle, unicycle_step


@dataclass
class Obstacle:
    x: float
    y: float
    radius: float


@dataclass
class Arena:
    width: float = 10.0
    height: float = 10.0
    n_obstacles: int = 5
    obstacle_radius_range: Tuple[float, float] = (0.25, 0.6)
    seed: int = 0
    robot_radius: float = 0.18  # approx. TurtleBot 4 Lite footprint radius
    obstacles: List[Obstacle] = field(default_factory=list)

    def __post_init__(self):
        rng = random.Random(self.seed)
        if not self.obstacles:
            attempts = 0
            while len(self.obstacles) < self.n_obstacles and attempts < 500:
                attempts += 1
                r = rng.uniform(*self.obstacle_radius_range)
                x = rng.uniform(r + 0.5, self.width - r - 0.5)
                y = rng.uniform(r + 0.5, self.height - r - 0.5)
                # keep clear of the arena centre, where robots start
                if math.hypot(x - self.width / 2, y - self.height / 2) < 1.5:
                    continue
                if any(math.hypot(x - o.x, y - o.y) < (r + o.radius + 0.6) for o in self.obstacles):
                    continue
                self.obstacles.append(Obstacle(x, y, r))

    # ------------------------------------------------------------------
    def in_collision(self, x: float, y: float, robot_radius: float = None) -> bool:
        rr = self.robot_radius if robot_radius is None else robot_radius
        if x - rr < 0 or x + rr > self.width:
            return True
        if y - rr < 0 or y + rr > self.height:
            return True
        for o in self.obstacles:
            if math.hypot(x - o.x, y - o.y) < (o.radius + rr):
                return True
        return False

    # ------------------------------------------------------------------
    def cast_lidar(self, pose, n_rays: int = 360, max_range: float = 8.0):
        """360 degree LIDAR simulation, centred on the robot's current
        heading (matches a typical TurtleBot 4 / RPLIDAR-style
        full-surround scan). Uses closed-form ray/wall and ray/circle
        intersection (no step-marching) so it stays fast enough to run
        thousands of matches for tuning.

        Ranges are reported in CONFIGURATION SPACE, i.e. against
        obstacles/walls inflated by `robot_radius` -- the same
        "inflation layer" trick real ROS2 navigation stacks (Nav2) use.
        A raw point-robot ray-cast against the true obstacle surfaces
        would report a direction as clear right up until the robot's
        *centre* touches the surface, while the robot's *body* (which has
        real width) would have already clipped it well before that. Since
        `in_collision` below also checks centre-to-centre distance against
        `obstacle_radius + robot_radius`, inflating here keeps what the
        "LIDAR" reports consistent with what will actually collide.
        """
        x, y, theta = pose
        angle_min = -math.pi
        angle_increment = 2 * math.pi / n_rays
        ranges = []
        for i in range(n_rays):
            ang = theta + angle_min + i * angle_increment
            dx, dy = math.cos(ang), math.sin(ang)
            hit = self._raycast_single(x, y, dx, dy, max_range)
            ranges.append(hit)
        return ranges, angle_min, angle_increment

    def _raycast_single(self, x, y, dx, dy, max_range):
        best = max_range
        rr = self.robot_radius

        # --- walls of the enclosing square (inflated inward by robot_radius) ---
        if dx > 1e-9:
            t = (self.width - rr - x) / dx
            if 0 <= t < best:
                best = t
        elif dx < -1e-9:
            t = (rr - x) / dx
            if 0 <= t < best:
                best = t
        if dy > 1e-9:
            t = (self.height - rr - y) / dy
            if 0 <= t < best:
                best = t
        elif dy < -1e-9:
            t = (rr - y) / dy
            if 0 <= t < best:
                best = t

        # --- static circular obstacles, inflated by robot_radius ---
        for o in self.obstacles:
            lx, ly = o.x - x, o.y - y
            tca = lx * dx + ly * dy
            if tca < 0:
                continue  # obstacle is behind this ray
            d2 = lx * lx + ly * ly - tca * tca
            r_inflated = o.radius + rr
            r2 = r_inflated * r_inflated
            if d2 > r2:
                continue
            thc = math.sqrt(max(r2 - d2, 0.0))
            t0 = tca - thc
            t = t0 if t0 >= 0 else tca + thc
            if 0 <= t < best:
                best = t

        return max(best, 0.0)

    # ------------------------------------------------------------------
    def step(self, pose, linear_vel: float, angular_vel: float, dt: float,
              max_linear: float = 0.31, max_angular: float = 1.9):
        """Integrate motion and clamp to the arena / obstacles, matching
        the TurtleBot 4 Lite's approximate max speeds (~0.31 m/s, ~1.9 rad/s)."""
        linear_vel = max(-max_linear, min(max_linear, linear_vel))
        angular_vel = max(-max_angular, min(max_angular, angular_vel))
        new_pose = unicycle_step(pose, linear_vel, angular_vel, dt)
        if self.in_collision(new_pose[0], new_pose[1]):
            # Simple "bump and stop" collision response -- good enough for
            # tuning; Gazebo's physics engine will handle this for real.
            return [pose[0], pose[1], new_pose[2]]
        return new_pose
