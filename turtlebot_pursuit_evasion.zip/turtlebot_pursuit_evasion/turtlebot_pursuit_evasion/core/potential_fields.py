"""
potential_fields.py
--------------------
Artificial Potential Field (APF) helpers. Both the Catcher and the Runner
avoid obstacles the same way: every LIDAR beam that is closer than
`influence_radius` pushes the robot away, with a force that grows sharply
as the obstacle gets closer (classic APF repulsion). Attraction terms
(towards the opponent, towards open space, ...) are computed separately
in each brain and summed with this repulsion vector.
"""
import math
from typing import Iterable, Tuple

from .geometry import wrap_angle


def obstacle_repulsion_from_scan(
    ranges: Iterable[float],
    angle_min: float,
    angle_increment: float,
    influence_radius: float = 1.0,
    gain: float = 1.5,
    max_range: float = 8.0,
) -> Tuple[float, float]:
    """Compute a net repulsive vector (robot local frame, +x forward,
    +y left -- REP-103 / ROS convention) from a LaserScan-like ranges array.

    Standard APF repulsion magnitude per beam:
        F = gain * (1/r - 1/influence_radius) / r^2   for r < influence_radius
    directed away from the obstacle (back along the beam).
    """
    fx = 0.0
    fy = 0.0
    angle = angle_min
    for r in ranges:
        # Treat inf/nan/out-of-range/zero readings as "no obstacle on this beam"
        if r is None or math.isnan(r) or math.isinf(r) or r <= 0.02 or r >= max_range:
            angle += angle_increment
            continue
        if r < influence_radius:
            mag = gain * (1.0 / r - 1.0 / influence_radius) / (r * r)
            # Beam points from robot towards the obstacle at `angle`; the
            # repulsive force points the opposite way.
            fx += -mag * math.cos(angle)
            fy += -mag * math.sin(angle)
        angle += angle_increment
    return fx, fy


def most_open_direction(
    ranges: Iterable[float],
    angle_min: float,
    angle_increment: float,
    max_range: float = 8.0,
    smoothing_window: int = 5,
) -> float:
    """Return the beam angle (robot local frame) with the largest clear
    distance, after a small moving-average smoothing pass so a single
    noisy/lucky beam doesn't dominate. Used by the Runner to head towards
    open space instead of a corner.
    """
    ranges = [
        (max_range if (r is None or math.isnan(r) or math.isinf(r) or r <= 0.0) else min(r, max_range))
        for r in ranges
    ]
    n = len(ranges)
    if n == 0:
        return 0.0

    half = smoothing_window // 2
    best_idx = 0
    best_val = -1.0
    for i in range(n):
        lo, hi = i - half, i + half
        window = [ranges[j % n] for j in range(lo, hi + 1)]
        avg = sum(window) / len(window)
        if avg > best_val:
            best_val = avg
            best_idx = i
    return angle_min + best_idx * angle_increment


def select_best_heading(
    ranges: Iterable[float],
    angle_min: float,
    angle_increment: float,
    preferred_angle: float,
    safe_distance: float = 2.5,
    min_clearance: float = 0.30,
    preference_weight: float = 1.0,
    clearance_weight: float = 1.0,
    sample_stride: int = 4,
) -> Tuple[float, float]:
    """Vector-Field-Histogram-style heading selection.

    Scores every candidate beam direction on two things: how closely it
    matches `preferred_angle` (e.g. "away from the Catcher") and how much
    open space lies that way, then returns the best-scoring one. This is
    what lets the Runner avoid blindly fleeing straight into a wall or a
    corner just because that happens to be directly away from the
    Catcher -- a pure vector-sum (APF) flee force has no way to "see"
    that the straight-line-away direction is a dead end until it's
    already very close to it. Headings with less than `min_clearance` are
    excluded outright (not safely driveable).

    Returns (best_angle, clearance_at_best_angle). If literally no beam
    clears `min_clearance` (fully boxed in), falls back to the single
    beam with the most clearance, regardless of direction.
    """
    ranges = list(ranges)
    n = len(ranges)
    if n == 0:
        return preferred_angle, 0.0

    best_angle = preferred_angle
    best_score = -1.0
    best_clearance = 0.0
    found_any = False

    fallback_angle = preferred_angle
    fallback_clearance = -1.0

    for i in range(0, n, max(1, sample_stride)):
        r = ranges[i]
        if r is None or r != r:  # NaN check
            continue
        ang = angle_min + i * angle_increment

        if r > fallback_clearance:
            fallback_clearance = r
            fallback_angle = ang

        if r <= min_clearance:
            continue

        clearance_score = min(r, safe_distance) / safe_distance
        align_score = (math.cos(wrap_angle(ang - preferred_angle)) + 1.0) / 2.0
        score = clearance_weight * clearance_score + preference_weight * align_score
        if score > best_score:
            best_score = score
            best_angle = ang
            best_clearance = r
            found_any = True

    if not found_any:
        return fallback_angle, max(fallback_clearance, 0.0)
    return best_angle, best_clearance


def clearance_at_angle(
    ranges: Iterable[float],
    angle_min: float,
    angle_increment: float,
    angle: float,
) -> float:
    """Look up the (nearest-beam) LIDAR range at a specific local-frame
    angle. Used to check clearance in the direction the robot is ACTUALLY
    driving (its current heading, angle=0) as opposed to the direction it
    is steering towards -- a robot moving forward turns gradually, so a
    target heading being clear does not by itself mean the current
    heading is."""
    ranges = list(ranges)
    n = len(ranges)
    if n == 0:
        return 0.0
    idx = int(round(wrap_angle(angle - angle_min) / angle_increment)) % n
    r = ranges[idx]
    if r is None or r != r:
        return 0.0
    return r


def combine(*vectors: Tuple[float, float]) -> Tuple[float, float]:
    fx = sum(v[0] for v in vectors)
    fy = sum(v[1] for v in vectors)
    return fx, fy
