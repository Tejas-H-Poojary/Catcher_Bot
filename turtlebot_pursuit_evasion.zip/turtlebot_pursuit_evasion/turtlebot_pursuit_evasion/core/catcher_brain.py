"""
catcher_brain.py
-----------------
Pure decision-making logic for the Catcher role. No ROS imports here on
purpose: this class is instantiated both by catcher_node.py (real robot /
Gazebo) and by simulate.py (standalone tuning), so the exact same
algorithm is what gets tested and what gets deployed.

Strategy
    1. If the opponent has not been detected yet, spin slowly in place to
       sweep the LIDAR and search (a real match starts at a known 3m
       separation, so this mostly matters after occlusion behind an
       obstacle).
    2. If detected, keep a short history of the opponent's estimated
       world position and finite-difference it into a velocity estimate.
    3. Aim not at the opponent's current position but at a predicted
       "intercept point" a short lead time ahead -- this is what turns a
       tail-chase into a real pursuit and matters a lot once the Runner
       starts juking around obstacles.
    4. Blend that attraction vector with an obstacle-repulsion vector
       (potential_fields.obstacle_repulsion_from_scan) and drive a simple
       heading-proportional controller towards the sum.
"""
import math
from collections import deque

from .geometry import wrap_angle, clamp, world_to_robot_frame, robot_to_world_frame
from .potential_fields import obstacle_repulsion_from_scan, combine


class CatcherBrain:
    def __init__(
        self,
        max_linear_speed: float = 0.31,
        max_angular_speed: float = 1.9,
        attractive_gain: float = 1.0,
        obstacle_influence_radius: float = 1.0,
        obstacle_gain: float = 1.8,
        lead_time: float = 0.6,
        heading_kp: float = 2.2,
        search_angular_speed: float = 0.8,
        velocity_history_len: int = 5,
    ):
        self.max_linear_speed = max_linear_speed
        self.max_angular_speed = max_angular_speed
        self.attractive_gain = attractive_gain
        self.obstacle_influence_radius = obstacle_influence_radius
        self.obstacle_gain = obstacle_gain
        self.lead_time = lead_time
        self.heading_kp = heading_kp
        self.search_angular_speed = search_angular_speed

        self._history = deque(maxlen=velocity_history_len)  # (t, world_x, world_y)
        self._t = 0.0

    def reset(self):
        self._history.clear()
        self._t = 0.0

    # ------------------------------------------------------------------
    def _estimate_opponent_velocity(self):
        if len(self._history) < 2:
            return 0.0, 0.0
        t0, x0, y0 = self._history[0]
        t1, x1, y1 = self._history[-1]
        dt = t1 - t0
        if dt < 1e-3:
            return 0.0, 0.0
        return (x1 - x0) / dt, (y1 - y0) / dt

    # ------------------------------------------------------------------
    def compute_cmd(self, own_pose, opponent_relative, laser_ranges,
                     angle_min, angle_increment, dt):
        """
        own_pose: (x, y, theta) in world frame (from odometry)
        opponent_relative: (dx, dy) opponent position in the ROBOT's local
            frame, or None if not currently detected
        laser_ranges, angle_min, angle_increment: current LIDAR scan
        dt: seconds since the previous control update

        returns (linear_vel, angular_vel)
        """
        self._t += dt
        x, y, theta = own_pose

        if opponent_relative is None:
            return self._search_behavior()

        dx_r, dy_r = opponent_relative
        # Track opponent in world frame so velocity estimation is not
        # corrupted by our own rotation.
        wdx, wdy = robot_to_world_frame(dx_r, dy_r, theta)
        opp_world_x, opp_world_y = x + wdx, y + wdy
        self._history.append((self._t, opp_world_x, opp_world_y))

        vx, vy = self._estimate_opponent_velocity()
        intercept_x = opp_world_x + vx * self.lead_time
        intercept_y = opp_world_y + vy * self.lead_time

        # Attractive vector, computed in the robot's local frame.
        target_dx = intercept_x - x
        target_dy = intercept_y - y
        local_tx, local_ty = world_to_robot_frame(target_dx, target_dy, theta)
        dist = math.hypot(local_tx, local_ty)
        if dist > 1e-6:
            att_x = self.attractive_gain * local_tx / dist
            att_y = self.attractive_gain * local_ty / dist
        else:
            att_x = att_y = 0.0

        # Shrink the obstacle-influence radius as we close in on the
        # target. Without this, a Runner backed up against a wall creates
        # a classic APF "goal near obstacle" trap: the wall directly
        # behind the target pushes the Catcher back exactly as hard as
        # the target pulls it forward, and the Catcher settles into a
        # stable standoff distance instead of completing the capture.
        # Once we're closer than the base influence radius, only react to
        # obstacles nearer than the target itself (real obstacles in the
        # way still trigger this fully; the wall beyond the target does not).
        raw_dist = math.hypot(dx_r, dy_r)
        effective_influence_radius = min(self.obstacle_influence_radius, max(0.2, raw_dist - 0.35))

        rep_x, rep_y = obstacle_repulsion_from_scan(
            laser_ranges, angle_min, angle_increment,
            influence_radius=effective_influence_radius,
            gain=self.obstacle_gain,
        )

        fx, fy = combine((att_x, att_y), (rep_x, rep_y))
        if abs(fx) < 1e-6 and abs(fy) < 1e-6:
            return 0.0, 0.0

        desired_heading = math.atan2(fy, fx)
        heading_error = wrap_angle(desired_heading)  # already local frame -> current heading is 0
        angular_vel = clamp(self.heading_kp * heading_error, -self.max_angular_speed, self.max_angular_speed)

        # Slow down (and, if needed, stop/reverse the turn) when the
        # required turn is sharp -- avoids overshooting around obstacles.
        turn_factor = max(0.0, math.cos(heading_error))
        linear_vel = self.max_linear_speed * turn_factor

        # Close the last stretch smoothly rather than ramming full-speed.
        if raw_dist < 0.6:
            linear_vel = min(linear_vel, self.max_linear_speed * (raw_dist / 0.6) + 0.05)

        return clamp(linear_vel, 0.0, self.max_linear_speed), angular_vel

    # ------------------------------------------------------------------
    def _search_behavior(self):
        """No opponent in view: rotate slowly in place to re-acquire it
        with the LIDAR / vision pipeline."""
        return 0.0, self.search_angular_speed
