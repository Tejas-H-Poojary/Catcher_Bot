"""
geometry.py
-----------
Small, dependency-free math helpers used by the brains, the perception
module and the standalone simulator. Kept separate from ROS so it can be
unit-tested (and run) with plain `python3`, no ROS2 install required.
"""
import math


def wrap_angle(theta: float) -> float:
    """Normalize an angle to (-pi, pi]."""
    return (theta + math.pi) % (2 * math.pi) - math.pi


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def hypot(dx: float, dy: float) -> float:
    return math.hypot(dx, dy)


def world_to_robot_frame(dx: float, dy: float, theta: float):
    """Rotate a world-frame vector (dx, dy) into the robot's local frame,
    given the robot's heading `theta` (radians, world frame)."""
    c, s = math.cos(-theta), math.sin(-theta)
    rx = dx * c - dy * s
    ry = dx * s + dy * c
    return rx, ry


def robot_to_world_frame(rx: float, ry: float, theta: float):
    """Inverse of world_to_robot_frame."""
    c, s = math.cos(theta), math.sin(theta)
    dx = rx * c - ry * s
    dy = rx * s + ry * c
    return dx, dy


def normalize(vx: float, vy: float):
    """Return a unit vector in the same direction as (vx, vy).
    Returns (0, 0) for the zero vector instead of raising."""
    mag = math.hypot(vx, vy)
    if mag < 1e-9:
        return 0.0, 0.0
    return vx / mag, vy / mag


def unicycle_step(pose, linear_vel: float, angular_vel: float, dt: float):
    """Integrate a simple unicycle model (matches TurtleBot's differential
    drive kinematics closely enough for planning/testing purposes).
    pose = [x, y, theta] -> returns new pose list.
    """
    x, y, theta = pose
    x += linear_vel * math.cos(theta) * dt
    y += linear_vel * math.sin(theta) * dt
    theta = wrap_angle(theta + angular_vel * dt)
    return [x, y, theta]
