"""
runner_brain.py
-----------------
Pure decision-making logic for the Runner role. Same split as
catcher_brain.py: no ROS imports, shared between runner_node.py and
simulate.py.

Strategy
    1. Compute the direction directly away from the Catcher (when it's
       within `threat_radius`).
    2. Instead of just driving that raw direction (which can walk the
       Runner straight into a wall or a corner -- it only knows "away
       from Catcher", not "is this actually a safe way to go"), score
       EVERY direction the LIDAR can see on two things: how well it
       matches "away from Catcher", and how much open space is actually
       that way, then drive the best-scoring one
       (potential_fields.select_best_heading -- a small Vector Field
       Histogram). This is what lets the Runner peel off along a wall or
       cut back through the middle of the arena instead of running
       itself into a dead end.
    3. Weave (juke) the *preferred* escape angle side to side over time
       instead of holding a constant bearing. A straight, unwavering
       flight is exactly what a predictive pursuer (see
       catcher_brain.py's lead-time intercept) is built to cut off;
       periodically biasing the preferred angle left/right confuses the
       Catcher's finite-difference velocity estimate.
    4. When the Catcher is far away / not detected, patrol: keep moving
       in a slowly-varying wander pattern so the Runner isn't sitting
       still and easy to close in on, and so it doesn't telegraph its
       position by camping in one spot.
"""
import math
import random

from .geometry import wrap_angle, clamp
from .potential_fields import most_open_direction, select_best_heading, clearance_at_angle


class RunnerBrain:
    def __init__(
        self,
        max_linear_speed: float = 0.31,
        max_angular_speed: float = 1.9,
        threat_radius: float = 4.5,
        heading_kp: float = 2.8,
        safe_distance: float = 2.5,
        min_clearance: float = 0.30,
        patrol_turn_std: float = 0.4,
        juke_angle: float = 0.5,
        juke_period: float = 1.1,
        heading_smoothing: float = 0.4,
        min_turn_factor: float = 0.65,
        seed: int = 42,
    ):
        self.max_linear_speed = max_linear_speed
        self.max_angular_speed = max_angular_speed
        self.threat_radius = threat_radius
        self.heading_kp = heading_kp
        self.safe_distance = safe_distance
        self.min_clearance = min_clearance
        self.patrol_turn_std = patrol_turn_std
        self.juke_angle = juke_angle
        self.juke_period = juke_period
        self.heading_smoothing = heading_smoothing
        self.min_turn_factor = min_turn_factor

        self._rng = random.Random(seed)
        self._patrol_bias = 0.0
        self._t = 0.0
        self._juke_sign = 1.0
        # Randomize each robot's juke phase a little so it isn't perfectly
        # periodic / learnable across a whole match.
        self._next_juke_flip = self._rng.uniform(0.5, juke_period)
        self._preferred_vec = None  # (cos, sin) EMA of the raw away-from-Catcher preference

    def reset(self):
        self._patrol_bias = 0.0
        self._t = 0.0
        self._next_juke_flip = self._rng.uniform(0.5, self.juke_period)
        self._preferred_vec = None

    # ------------------------------------------------------------------
    def compute_cmd(self, own_pose, opponent_relative, laser_ranges,
                     angle_min, angle_increment, dt):
        """
        own_pose: (x, y, theta) world frame (unused directly here, kept
            for a consistent interface with CatcherBrain / future use).
        opponent_relative: (dx, dy) Catcher's position in the Runner's
            LOCAL frame, or None if not currently detected.
        laser_ranges, angle_min, angle_increment: current LIDAR scan.
        dt: seconds since previous control update.

        returns (linear_vel, angular_vel)
        """
        self._t += dt
        if self._t >= self._next_juke_flip:
            self._juke_sign *= -1.0
            self._next_juke_flip = self._t + self._rng.uniform(0.7, 1.3) * self.juke_period

        threatened = False
        dist = None
        if opponent_relative is not None:
            dx, dy = opponent_relative
            dist = math.hypot(dx, dy)
            threatened = dist < self.threat_radius and dist > 1e-6

        open_ang = most_open_direction(laser_ranges, angle_min, angle_increment)

        if not threatened:
            # No immediate danger: patrol, biased gently towards open space
            # so it still tends to move away from walls/clutter.
            self._preferred_vec = None  # don't carry a stale preference into the next chase
            return self._patrol_behavior(open_ang, dt)

        away_angle = math.atan2(-dy, -dx)
        # Weave the preferred escape bearing rather than holding it dead
        # steady. A straight, unwavering flight is exactly what a
        # predictive pursuer is built to cut off.
        raw_preferred_angle = wrap_angle(away_angle + self._juke_sign * self.juke_angle * 0.5)

        # Smooth the *preference we feed in*, not the *candidate VFH
        # picks*. Smoothing the winning candidate is unsafe: if two
        # genuinely-safe options straddle an obstacle (e.g. "pass left of
        # it" and "pass right of it"), averaging them can point straight
        # at the obstacle between them even though neither real option
        # did. Smoothing the input preference instead means
        # select_best_heading always returns one single, actually-clear
        # beam -- it just changes gradually which one that is.
        raw_vec = (math.cos(raw_preferred_angle), math.sin(raw_preferred_angle))
        if self._preferred_vec is None:
            self._preferred_vec = raw_vec
        else:
            a = self.heading_smoothing
            bx = a * raw_vec[0] + (1 - a) * self._preferred_vec[0]
            by = a * raw_vec[1] + (1 - a) * self._preferred_vec[1]
            norm = math.hypot(bx, by) or 1.0
            self._preferred_vec = (bx / norm, by / norm)
        preferred_angle = math.atan2(self._preferred_vec[1], self._preferred_vec[0])

        # The closer the Catcher gets, the more we care about raw
        # clearance (don't clip a wall while escaping) vs. holding an
        # exact bearing away from it.
        danger = clamp((self.threat_radius - dist) / self.threat_radius, 0.0, 1.0)
        preference_weight = 1.4 - 0.6 * danger   # 1.4 far -> 0.8 very close
        clearance_weight = 0.8 + 0.6 * danger    # 0.8 far -> 1.4 very close

        best_angle, clearance = select_best_heading(
            laser_ranges, angle_min, angle_increment,
            preferred_angle=preferred_angle,
            safe_distance=self.safe_distance,
            min_clearance=self.min_clearance,
            preference_weight=preference_weight,
            clearance_weight=clearance_weight,
        )

        heading_error = wrap_angle(best_angle)  # local frame -> current heading is 0
        angular_vel = clamp(self.heading_kp * heading_error, -self.max_angular_speed, self.max_angular_speed)

        # Unlike the Catcher, the Runner should keep moving fast even
        # through a moderately sharp turn -- stopping to turn is a good
        # way to get caught. But still slow right down if what's
        # actually ahead of it (its CURRENT heading, not the target
        # heading it's turning towards) is tight -- linear velocity
        # drives the robot along its current heading, not the target one,
        # so gating on the target's clearance alone lets it coast into
        # something while it's still mid-turn.
        forward_clearance = clearance_at_angle(laser_ranges, angle_min, angle_increment, 0.0)
        turn_factor = max(self.min_turn_factor, math.cos(heading_error))
        clearance_factor = clamp((min(clearance, forward_clearance) - self.min_clearance) / 0.5, 0.0, 1.0)
        linear_vel = self.max_linear_speed * turn_factor * clearance_factor

        return clamp(linear_vel, 0.0, self.max_linear_speed), angular_vel

    # ------------------------------------------------------------------
    def _patrol_behavior(self, open_ang, dt):
        """Wander with a slow random-walk turn, biased towards the most
        open direction currently visible, so the Runner keeps covering
        ground instead of idling in a corner while waiting to be found."""
        self._patrol_bias += self._rng.gauss(0.0, self.patrol_turn_std) * dt
        self._patrol_bias = clamp(self._patrol_bias, -1.0, 1.0)
        bias_towards_open = clamp(wrap_angle(open_ang), -1.0, 1.0) * 0.3
        angular_vel = clamp(self._patrol_bias + bias_towards_open, -self.max_angular_speed, self.max_angular_speed)
        linear_vel = self.max_linear_speed * 0.7
        return linear_vel, angular_vel
