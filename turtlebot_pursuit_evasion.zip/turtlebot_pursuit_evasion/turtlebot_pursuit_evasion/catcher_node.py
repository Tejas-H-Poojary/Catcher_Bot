"""
catcher_node.py
-----------------
ROS2 node wrapper around CatcherBrain (core/catcher_brain.py has the
actual pursuit logic). This file is intentionally thin: it only handles
ROS I/O (subscriptions, publishing, parameter loading) and hands
everything else off to the brain, which is the same code exercised by
simulate.py.

ASSUMPTIONS -- update once the official technical rulebook is released
(see README.md "Assumptions we had to make"):
  - Runs in a namespace (e.g. 'catcher') alongside the Runner's 'runner'
    namespace, each using the TurtleBot 4's default relative topic names:
        <ns>/odom       nav_msgs/Odometry
        <ns>/scan       sensor_msgs/LaserScan
        <ns>/cmd_vel    geometry_msgs/Twist
  - Opponent localisation is handled by perception.OpponentTracker
    (ground-truth Gazebo model states by default -- see perception.py for
    the 'lidar' fallback mode and its own caveats).
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan

from .core.catcher_brain import CatcherBrain
from .perception import OpponentTracker, quaternion_to_yaw


class CatcherNode(Node):
    def __init__(self):
        super().__init__('catcher_node')

        # -- Parameters (override via config/params.yaml) --
        self.declare_parameter('opponent_model_name', 'runner')
        self.declare_parameter('perception_mode', 'ground_truth')  # 'ground_truth' | 'lidar'
        self.declare_parameter('static_obstacles', [])  # flat [x1,y1,r1, x2,y2,r2, ...] for 'lidar' mode
        self.declare_parameter('control_frequency', 20.0)
        self.declare_parameter('max_linear_speed', 0.31)
        self.declare_parameter('max_angular_speed', 1.9)
        self.declare_parameter('attractive_gain', 1.0)
        self.declare_parameter('obstacle_influence_radius', 1.0)
        self.declare_parameter('obstacle_gain', 1.8)
        self.declare_parameter('lead_time', 0.6)
        self.declare_parameter('heading_kp', 2.2)
        self.declare_parameter('search_angular_speed', 0.8)

        self.brain = CatcherBrain(
            max_linear_speed=self.get_parameter('max_linear_speed').value,
            max_angular_speed=self.get_parameter('max_angular_speed').value,
            attractive_gain=self.get_parameter('attractive_gain').value,
            obstacle_influence_radius=self.get_parameter('obstacle_influence_radius').value,
            obstacle_gain=self.get_parameter('obstacle_gain').value,
            lead_time=self.get_parameter('lead_time').value,
            heading_kp=self.get_parameter('heading_kp').value,
            search_angular_speed=self.get_parameter('search_angular_speed').value,
        )

        flat_obstacles = list(self.get_parameter('static_obstacles').value)
        static_obstacles = [tuple(flat_obstacles[i:i + 3]) for i in range(0, len(flat_obstacles), 3)]
        self.tracker = OpponentTracker(
            self,
            opponent_model_name=self.get_parameter('opponent_model_name').value,
            mode=self.get_parameter('perception_mode').value,
            static_obstacles=static_obstacles,
        )

        self._own_pose = None
        self._last_scan = None
        self._last_control_time = self.get_clock().now()

        self.create_subscription(Odometry, 'odom', self._odom_cb, 10)
        self.create_subscription(LaserScan, 'scan', self._scan_cb, 10)
        self.cmd_pub = self.create_publisher(Twist, 'cmd_vel', 10)

        control_period = 1.0 / float(self.get_parameter('control_frequency').value)
        self.create_timer(control_period, self._control_loop)

        self.get_logger().info(
            f"CatcherNode ready (perception_mode="
            f"{self.get_parameter('perception_mode').value})")

    # ------------------------------------------------------------------
    def _odom_cb(self, msg: Odometry):
        p = msg.pose.pose.position
        yaw = quaternion_to_yaw(msg.pose.pose.orientation)
        self._own_pose = (p.x, p.y, yaw)

    def _scan_cb(self, msg: LaserScan):
        self._last_scan = msg
        if self.get_parameter('perception_mode').value == 'lidar' and self._own_pose is not None:
            self.tracker.update_from_scan(
                self._own_pose, msg.ranges, msg.angle_min, msg.angle_increment,
                max_range=msg.range_max,
            )

    def _control_loop(self):
        if self._own_pose is None or self._last_scan is None:
            return  # still waiting for the first odom + scan message

        now = self.get_clock().now()
        dt = (now - self._last_control_time).nanoseconds / 1e9
        self._last_control_time = now
        if dt <= 0.0:
            return

        opponent_rel = self.tracker.get_opponent_relative(self._own_pose)
        linear, angular = self.brain.compute_cmd(
            self._own_pose, opponent_rel,
            self._last_scan.ranges, self._last_scan.angle_min, self._last_scan.angle_increment,
            dt,
        )

        twist = Twist()
        twist.linear.x = linear
        twist.angular.z = angular
        self.cmd_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = CatcherNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
