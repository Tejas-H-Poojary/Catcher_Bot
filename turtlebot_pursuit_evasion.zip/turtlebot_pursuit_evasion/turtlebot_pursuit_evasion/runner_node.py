"""
runner_node.py
-----------------
ROS2 node wrapper around RunnerBrain (core/runner_brain.py has the actual
evasion logic). Same thin-wrapper pattern as catcher_node.py: ROS I/O
only, all decision-making delegated to the brain shared with
simulate.py.

See catcher_node.py's docstring for the topic/namespace/perception
assumptions -- they're identical here, just swapped Catcher<->Runner.
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan

from .core.runner_brain import RunnerBrain
from .perception import OpponentTracker, quaternion_to_yaw


class RunnerNode(Node):
    def __init__(self):
        super().__init__('runner_node')

        # -- Parameters (override via config/params.yaml) --
        self.declare_parameter('opponent_model_name', 'catcher')
        self.declare_parameter('perception_mode', 'ground_truth')  # 'ground_truth' | 'lidar'
        self.declare_parameter('static_obstacles', [])  # flat [x1,y1,r1, x2,y2,r2, ...] for 'lidar' mode
        self.declare_parameter('control_frequency', 20.0)
        self.declare_parameter('max_linear_speed', 0.31)
        self.declare_parameter('max_angular_speed', 1.9)
        self.declare_parameter('threat_radius', 4.5)
        self.declare_parameter('heading_kp', 2.8)
        self.declare_parameter('safe_distance', 2.5)
        self.declare_parameter('min_clearance', 0.30)
        self.declare_parameter('patrol_turn_std', 0.4)
        self.declare_parameter('juke_angle', 0.5)
        self.declare_parameter('juke_period', 1.1)
        self.declare_parameter('heading_smoothing', 0.4)
        self.declare_parameter('min_turn_factor', 0.65)
        self.declare_parameter('brain_seed', 42)

        self.brain = RunnerBrain(
            max_linear_speed=self.get_parameter('max_linear_speed').value,
            max_angular_speed=self.get_parameter('max_angular_speed').value,
            threat_radius=self.get_parameter('threat_radius').value,
            heading_kp=self.get_parameter('heading_kp').value,
            safe_distance=self.get_parameter('safe_distance').value,
            min_clearance=self.get_parameter('min_clearance').value,
            patrol_turn_std=self.get_parameter('patrol_turn_std').value,
            juke_angle=self.get_parameter('juke_angle').value,
            juke_period=self.get_parameter('juke_period').value,
            heading_smoothing=self.get_parameter('heading_smoothing').value,
            min_turn_factor=self.get_parameter('min_turn_factor').value,
            seed=self.get_parameter('brain_seed').value,
        )

        flat_obstacles = list(self.get_parameter('static_obstacles').value)
        static_obstacles = [tuple(flat_obstacles[i:i + 3]) for i in range(0, len(flat_obstacles), 3)]
        self.tracker = OpponentTracker(
            self,
            opponent_model_name=self.get_parameter('opponent_model_name').value,
            mode=self.get_parameter('perception_mode').value,
            static_obstacles=static_obstacles,
        )

        self._own_pose = None
        self._last_scan = None
        self._last_control_time = self.get_clock().now()

        self.create_subscription(Odometry, 'odom', self._odom_cb, 10)
        self.create_subscription(LaserScan, 'scan', self._scan_cb, 10)
        self.cmd_pub = self.create_publisher(Twist, 'cmd_vel', 10)

        control_period = 1.0 / float(self.get_parameter('control_frequency').value)
        self.create_timer(control_period, self._control_loop)

        self.get_logger().info(
            f"RunnerNode ready (perception_mode="
            f"{self.get_parameter('perception_mode').value})")

    # ------------------------------------------------------------------
    def _odom_cb(self, msg: Odometry):
        p = msg.pose.pose.position
        yaw = quaternion_to_yaw(msg.pose.pose.orientation)
        self._own_pose = (p.x, p.y, yaw)

    def _scan_cb(self, msg: LaserScan):
        self._last_scan = msg
        if self.get_parameter('perception_mode').value == 'lidar' and self._own_pose is not None:
            self.tracker.update_from_scan(
                self._own_pose, msg.ranges, msg.angle_min, msg.angle_increment,
                max_range=msg.range_max,
            )

    def _control_loop(self):
        if self._own_pose is None or self._last_scan is None:
            return  # still waiting for the first odom + scan message

        now = self.get_clock().now()
        dt = (now - self._last_control_time).nanoseconds / 1e9
        self._last_control_time = now
        if dt <= 0.0:
            return

        opponent_rel = self.tracker.get_opponent_relative(self._own_pose)
        linear, angular = self.brain.compute_cmd(
            self._own_pose, opponent_rel,
            self._last_scan.ranges, self._last_scan.angle_min, self._last_scan.angle_increment,
            dt,
        )

        twist = Twist()
        twist.linear.x = linear
        twist.angular.z = angular
        self.cmd_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = RunnerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
