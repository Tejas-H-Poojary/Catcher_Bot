"""
referee_node.py
------------------
OPTIONAL local testing utility -- NOT part of the official competition
infrastructure (the organizers' own judging system decides real match
outcomes), but useful for validating capture/timing logic end-to-end in
Gazebo before trusting the standalone simulator's numbers alone.

Subscribes to both robots' ground-truth odometry, applies the rulebook's
capture rule (within 0.5 m of each other, sustained continuously for
1.0 s) and the 3-minute inning timer, and publishes the running distance
plus the final match status.

Run alongside a match:
    ros2 run turtlebot_pursuit_evasion referee_node
or via launch/match.launch.py (default: enabled, disable with
use_referee:=false).
"""
import math

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import String, Float32


class RefereeNode(Node):
    def __init__(self):
        super().__init__('referee_node')

        self.declare_parameter('capture_radius', 0.5)
        self.declare_parameter('capture_hold_time', 1.0)
        self.declare_parameter('inning_duration', 180.0)
        self.declare_parameter('catcher_odom_topic', '/catcher/odom')
        self.declare_parameter('runner_odom_topic', '/runner/odom')

        self._capture_radius = float(self.get_parameter('capture_radius').value)
        self._capture_hold_time = float(self.get_parameter('capture_hold_time').value)
        self._inning_duration = float(self.get_parameter('inning_duration').value)

        self._catcher_pos = None
        self._runner_pos = None
        self._capture_timer = 0.0
        self._match_over = False
        self._start_time = self.get_clock().now()
        self._last_tick = self._start_time

        self.create_subscription(
            Odometry, self.get_parameter('catcher_odom_topic').value, self._catcher_cb, 10)
        self.create_subscription(
            Odometry, self.get_parameter('runner_odom_topic').value, self._runner_cb, 10)
        self.distance_pub = self.create_publisher(Float32, '/match/distance', 10)
        self.status_pub = self.create_publisher(String, '/match/status', 10)

        self.create_timer(0.1, self._tick)
        self.get_logger().info(
            f"RefereeNode ready: capture_radius={self._capture_radius}m, "
            f"hold={self._capture_hold_time}s, inning={self._inning_duration}s")

    # ------------------------------------------------------------------
    def _catcher_cb(self, msg: Odometry):
        p = msg.pose.pose.position
        self._catcher_pos = (p.x, p.y)

    def _runner_cb(self, msg: Odometry):
        p = msg.pose.pose.position
        self._runner_pos = (p.x, p.y)

    def _tick(self):
        if self._match_over or self._catcher_pos is None or self._runner_pos is None:
            return

        now = self.get_clock().now()
        dt = (now - self._last_tick).nanoseconds / 1e9
        self._last_tick = now
        elapsed = (now - self._start_time).nanoseconds / 1e9

        dist = math.hypot(self._catcher_pos[0] - self._runner_pos[0],
                           self._catcher_pos[1] - self._runner_pos[1])
        self.distance_pub.publish(Float32(data=dist))

        if dist < self._capture_radius:
            self._capture_timer += dt
        else:
            self._capture_timer = 0.0

        if self._capture_timer >= self._capture_hold_time:
            self._finish(f"CATCHER_WINS capture_time={elapsed:.1f}s final_dist={dist:.2f}m")
            return

        if elapsed >= self._inning_duration:
            self._finish(f"RUNNER_WINS final_dist={dist:.2f}m")
            return

    def _finish(self, message: str):
        self._match_over = True
        self.status_pub.publish(String(data=message))
        self.get_logger().info(message)


def main(args=None):
    rclpy.init(args=args)
    node = RefereeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
