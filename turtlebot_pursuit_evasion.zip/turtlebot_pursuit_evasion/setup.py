from setuptools import find_packages, setup

package_name = 'turtlebot_pursuit_evasion'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/match.launch.py']),
        ('share/' + package_name + '/config', ['config/params.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='you@example.com',
    description='Catcher/Runner nodes for the TurtleBot Pursuit & Evasion Challenge.',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'catcher_node = turtlebot_pursuit_evasion.catcher_node:main',
            'runner_node = turtlebot_pursuit_evasion.runner_node:main',
            'referee_node = turtlebot_pursuit_evasion.referee_node:main',
        ],
    },
)
