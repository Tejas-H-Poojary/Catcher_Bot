"""
match.launch.py
-----------------
Launches both the Catcher and the Runner, each in their own namespace
(using the TurtleBot 4's default relative topic names underneath: odom,
scan, cmd_vel), plus the optional local RefereeNode for testing outside
the official judging infrastructure.

This does NOT spawn Gazebo, the arena world, or the two TurtleBot 4
models -- that depends on whatever world file / spawn mechanism the
official technical rulebook specifies, which hasn't been released yet.
Include this launch file from whatever top-level launch file does that
part, e.g.:

    IncludeLaunchDescription(
        PythonLaunchDescriptionSource([pkg_share, '/launch/match.launch.py'])
    )

Usage:
    ros2 launch turtlebot_pursuit_evasion match.launch.py
    ros2 launch turtlebot_pursuit_evasion match.launch.py use_referee:=false
    ros2 launch turtlebot_pursuit_evasion match.launch.py params_file:=/path/to/custom_params.yaml
"""
import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('turtlebot_pursuit_evasion')
    default_params_file = os.path.join(pkg_share, 'config', 'params.yaml')

    use_referee_arg = DeclareLaunchArgument('use_referee', default_value='true')
    params_file_arg = DeclareLaunchArgument('params_file', default_value=default_params_file)

    use_referee = LaunchConfiguration('use_referee')
    params_file = LaunchConfiguration('params_file')

    catcher = Node(
        package='turtlebot_pursuit_evasion',
        executable='catcher_node',
        name='catcher_node',
        namespace='catcher',
        parameters=[params_file],
        output='screen',
    )

    runner = Node(
        package='turtlebot_pursuit_evasion',
        executable='runner_node',
        name='runner_node',
        namespace='runner',
        parameters=[params_file],
        output='screen',
    )

    referee = Node(
        package='turtlebot_pursuit_evasion',
        executable='referee_node',
        name='referee_node',
        parameters=[params_file],
        output='screen',
        condition=IfCondition(use_referee),
    )

    return LaunchDescription([
        use_referee_arg,
        params_file_arg,
        catcher,
        runner,
        referee,
    ])
